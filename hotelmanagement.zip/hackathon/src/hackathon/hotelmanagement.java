package hackathon;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JRadioButton;
import javax.swing.JTextField;
import javax.swing.border.Border;
import javax.swing.border.MatteBorder;


public class hotelmanagement {
	JTextField tcod;
	JTextField tcom;
	JTextField tcodeli;
	public static void main(String[] args) throws ClassNotFoundException, SQLException {
	
			Class.forName("com.mysql.jdbc.Driver");
		  
		Connection con = null;
		try {
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/hms","root","");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}  
		
		if (con != null)
		{
			System.out.println("Connected");
		}
		else
		{
			System.out.println("not Connected");
		}
		
			Statement statement=con.createStatement();
		
		
		JFrame f=new JFrame("Hotel Management System");

		f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		JLabel head;
		head = new JLabel("Hotel Management Systems");
		head.setForeground(Color.black);
		head.setFont(new Font("Serif", Font.BOLD, 25));
		head.setBounds(100, 10, 400, 50);
		f.add(head);

		JLabel label= new JLabel("");
		label.setBounds(5, 70, 350, 290);
		   Border border = BorderFactory.createLineBorder(Color.BLACK);
		   label.setBorder(border);
		   f.add(label);
		   
		   JLabel label2= new JLabel("");
		label2.setBounds(360, 70, 250, 290);
		   Border border2 = BorderFactory.createLineBorder(Color.BLACK);
		   label2.setBorder(border2);
		   f.add(label2);
		   
		   JLabel label3= new JLabel("");
		label3.setBounds(5, 370, 350, 170);
		   Border border3 = BorderFactory.createLineBorder(Color.BLACK);
		   label3.setBorder(border3);
		   f.add(label3);
		   
		   JLabel label4= new JLabel("");
		label4.setBounds(360, 370, 250, 170);
		   Border border4 = BorderFactory.createLineBorder(Color.BLACK);
		   label4.setBorder(border4);
		   f.add(label4);
		   
		   JLabel label5= new JLabel("");
		label5.setBounds(620, 70, 250, 470);
		   Border border5 = BorderFactory.createLineBorder(Color.BLACK);
		   label5.setBorder(border5);
		   f.add(label5);
		   
		   JLabel label6= new JLabel("");
		label6.setBounds(630, 170, 230, 360);
		   Border border6 = BorderFactory.createLineBorder(Color.BLUE);
		   label6.setBorder(border6);
		   f.add(label6);
		   
		   JLabel label7= new JLabel("");
		label7.setBounds(5, 550, 865, 80);
		   Border border7 = BorderFactory.createLineBorder(Color.BLACK);
		   label7.setBorder(border7);
		   f.add(label7);

		JLabel cb,cbm,csb;
		cb = new JLabel("Chicken Burger :");
		cb.setBounds(20, 110, 150, 30);
		final JTextField tcb = new JTextField();
		tcb.setBounds(150, 110, 170, 30);
		cbm = new JLabel("Chicken Burger Meal  :");
		cbm.setBounds(20, 150, 150, 30);
		final JTextField tcbm = new JTextField();
		tcbm.setBounds(150, 150, 170, 30);
		csb = new JLabel("Chineese Burger  :");
		csb.setBounds(20, 190, 150, 30);
		final JTextField tcsb = new JTextField();
		tcsb.setBounds(150, 190, 170, 30);
		f.add(cb);f.add(tcb);f.add(cbm);f.add(tcbm);f.add(csb);f.add(tcsb);


		JLabel drink;
		drink = new JLabel("Drink");
		drink.setForeground(Color.black);
		drink.setFont(new Font("Serif", Font.BOLD, 18));
		drink.setBounds(20, 230, 100, 50);
		f.add(drink);

		String drk[] = { "Tea", "Cofee", "Pepsi","Lime Juice" };
		JComboBox drkbox = new JComboBox(drk);
		drkbox.setBounds(20, 280, 150, 30);
		f.add(drkbox);

		JLabel qty;
		qty = new JLabel("Qty");
		qty.setForeground(Color.black);
		qty.setFont(new Font("Serif", Font.BOLD, 18));
		qty.setBounds(220, 230, 100, 50);
		f.add(qty);

		final JTextField tqty = new JTextField();
		tqty.setBounds(220, 280, 100, 30);
		f.add(tqty);

		JRadioButton hode= new JRadioButton("Home Delivery");
		hode.setBounds(20, 320, 150, 30);
		f.add(hode);

		JRadioButton tax= new JRadioButton("Tax");
		tax.setBounds(220, 320, 100, 30);
		f.add(tax);

		JLabel head2;
		head2 = new JLabel("Currency Converter");
		head2.setForeground(Color.black);
		head2.setFont(new Font("Serif", Font.BOLD, 18));
		head2.setBounds(370, 80, 200, 50);
		f.add(head2);

		String curr[] = { "India", "Canada", "Dubai","Singapoor" };
		JComboBox currbox = new JComboBox(curr);
		currbox.setBounds(390, 130, 180, 30);
		f.add(currbox);

		final JTextField tcurr = new JTextField();
		tcurr.setBounds(390, 180, 180, 30);
		f.add(tcurr);

		JButton bconvert= new JButton("Convert");
		bconvert.setBounds(390, 320, 80, 30);
		f.add(bconvert);
		JButton bclose= new JButton("Close");
		bclose.setBounds(500, 320, 80, 30);
		f.add(bclose);


		JLabel cod,com,codeli;
		cod = new JLabel("Cost of Drinks :");
		cod.setBounds(20, 410, 150, 30);
		final JTextField tcod = new JTextField();
		tcod.setBounds(150, 410, 170, 30);
		com = new JLabel("Cost of Meal  :");
		com.setBounds(20, 450, 150, 30);
		final JTextField tcom = new JTextField();
		tcom.setBounds(150, 450, 170, 30);
		codeli = new JLabel("Cost of Delivery  :");
		codeli.setBounds(20, 490, 150, 30);
		final JTextField tcodeli = new JTextField();
		tcodeli.setBounds(150, 490, 170, 30);
		f.add(cod);f.add(tcod);f.add(com);f.add(tcom);f.add(codeli);f.add(tcodeli);


		JLabel taxs,stotal,total;
		taxs = new JLabel("Tax :");
		taxs.setBounds(370, 410, 150, 30);
		final JTextField ttaxs = new JTextField();
		tcod.setBounds(450, 410, 150, 30);
		stotal = new JLabel("Sub Total  :");
		stotal.setBounds(370, 450, 150, 30);
		final JTextField tstotal = new JTextField();
		tstotal.setBounds(450, 450, 150, 30);
		total = new JLabel("Total  :");
		total.setBounds(370, 490, 150, 30);
		final JTextField ttotal = new JTextField();
		ttotal.setBounds(450, 490, 150, 30);
		f.add(taxs);f.add(ttaxs);f.add(stotal);f.add(tstotal);f.add(total);f.add(ttotal);
		final JTextField tadd = new JTextField();
		tadd.setBounds(150, 410, 170, 30);
		f.add(tadd);



		JButton b0= new JButton("0");
		b0.setBounds(650, 470, 45, 45);
		f.add(b0);

		JButton bdot= new JButton(".");
		bdot.setBounds(697, 470, 45, 45);
		f.add(bdot);

		JButton bddot= new JButton("...");
		bddot.setBounds(744, 470, 45, 45);
		f.add(bddot);

		JButton bequal= new JButton("=");
		bequal.setBounds(791, 470, 45, 45);
		f.add(bequal);

		JButton b1= new JButton("1");
		b1.setBounds(650, 423, 45, 45);
		f.add(b1);

		JButton b2 = new JButton("2");
		b2.setBounds(697, 423, 45, 45);
		f.add(b2);

		JButton b3= new JButton("3");
		b3.setBounds(744, 423, 45, 45);
		f.add(b3);

		JButton bdiv= new JButton("/");
		bdiv.setBounds(791, 423, 45, 45);
		f.add(bdiv);

		JButton b4= new JButton("4");
		b4.setBounds(650, 376, 45, 45);
		f.add(b4);

		JButton b5 = new JButton("5");
		b5.setBounds(697, 376, 45, 45);
		f.add(b5);

		JButton b6= new JButton("6");
		b6.setBounds(744, 376, 45, 45);
		f.add(b6);

		JButton bmul= new JButton("*");
		bmul.setBounds(791, 376, 45, 45);
		f.add(bmul);

		JButton b7= new JButton("7");
		b7.setBounds(650, 329, 45, 45);
		f.add(b7);

		JButton b8 = new JButton("8");
		b8.setBounds(697, 329, 45, 45);
		f.add(b8);

		JButton b9= new JButton("9");
		b9.setBounds(744, 329, 45, 45);
		f.add(b9);

		JButton bsub= new JButton("-");
		bsub.setBounds(791, 329, 45, 45);
		f.add(bsub);

		JButton bB= new JButton("B");
		bB.setBounds(650, 282, 45, 45);
		f.add(bB);

		JButton bC = new JButton("C");
		bC.setBounds(697, 282, 45, 45);
		f.add(bC);

		JButton btdot= new JButton("...");
		btdot.setBounds(744, 282, 45, 45);
		f.add(btdot);

		JButton badd= new JButton("+");
		badd.setBounds(791, 282, 45, 45);
		f.add(badd);

		final JTextField calctext = new JTextField();
		calctext.setBounds(650, 190, 190, 70);
		f.add(calctext);

		JButton bcalculator= new JButton("Calculator");
		bcalculator.setBounds(630, 140, 100, 30);
		f.add(bcalculator);

		JButton breciept = new JButton("Reciept");
		breciept.setBounds(730, 140, 100, 30);
		f.add(breciept);

		JButton btotal = new JButton("Total");
		btotal.setBounds(80, 570, 100, 30);
		f.add(btotal);

		JButton breceive = new JButton("Received");
		breceive.setBounds(220, 570, 100, 30);
		f.add(breceive);

		JButton breset = new JButton("Reset");
		breset.setBounds(360, 570, 100, 30);
		f.add(breset);

		JButton bexit = new JButton("Exit");
		bexit.setBounds(500, 570, 100, 30);
		f.add(bexit);

		JLabel head3 ;head3 = new JLabel("..");f.add(head3);
		btotal.addActionListener(new ActionListener(){  
    	    public void actionPerformed(ActionEvent e){  
    	    	int cb,cbm1,chebu;
    	    	cb=Integer.parseInt(tcb.getText());
    	    	cbm1=Integer.parseInt(tcbm.getText());
    	    	chebu=Integer.parseInt(tcsb.getText());
    	    	int cbc = 0,cbmc = 0,cbbc = 0;
    	    
    	    	ResultSet rs = null;
    	    	ResultSet as = null;
    	    	ResultSet bs = null;
				try {
					rs = statement.executeQuery("select cost from items where id=1");
					 as=statement.executeQuery("select cost from items where id=2");
					 bs=statement.executeQuery("select cost from items where id=3");
					
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
    	    	try {
					while(rs.next()) {
						
						 cbc  = rs.getInt("cost");
						 System.out.println(cbc);
						 
						 
						
					}
                    while(as.next()) {
						
						 cbmc  = rs.getInt("cost");
						
					}
                    while(bs.next()) {
						
						 cbbc  = rs.getInt("cost");
						
					}
                    
					
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
    	    	
    	    	cbc=cbc*cb;
                cbmc=cbmc*cbm1;
                cbbc=cbbc*chebu;
                cbc=cbc+cbmc+cbbc;
                tcom.setText(""+cbc);
                
    	    }
    	    });

    	    		

		   f.setVisible(true);
		f.setSize(900, 700);
		f.setLayout(null);
		f.setVisible(true);

		}
    	    }
